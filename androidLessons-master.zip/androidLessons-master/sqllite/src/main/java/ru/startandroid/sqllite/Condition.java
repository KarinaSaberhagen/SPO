package ru.startandroid.sqllite;

public class Condition {
    String text;
    String icon;
    int code;

    public Condition() {

    }

    public Condition(String text, String icon, int code) {
        this.text = text;
        this.icon = icon;
        this.code = code;
    }
}
